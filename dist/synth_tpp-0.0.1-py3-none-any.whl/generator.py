# from hawkesbook import exp_simulate_by_composition
from numba import njit, prange
import numpy.random as rnd
import numpy as np
from tqdm import tqdm
import random
import torch
from hawkesbook import exp_hawkes_compensators

def numba_seed(seed):
    rnd.seed(seed)
    np.random.seed(seed)
    random.seed(seed)

# @njit(nogil=True)
def exp_simulate_by_composition_T(𝛉, T):
    λ, α, β = 𝛉
    λˣ_k = λ
    t_k = 0

    ℋ = []
    while t_k < T:
        U_1 = rnd.rand()
        U_2 = rnd.rand()

        # Technically the following works, but without @njit
        # it will print out "RuntimeWarning: invalid value encountered in log".
        # This is because 1 + β/(λˣ_k + α - λ)*np.log(U_2) can be negative
        # so T_2 can be np.NaN. The Dassios & Zhao (2013) algorithm checks if this
        # expression is negative and handles it separately, though the lines
        # below have the same behaviour as t_k = min(T_1, np.NaN) will be T_1. 
        T_1 = t_k - np.log(U_1) / λ
        T_2 = t_k - np.log(1 + β/(λˣ_k + α - λ)*np.log(U_2))/β

        t_prev = t_k
        t_k = min(T_1, T_2)
        ℋ.append(t_k)

        if len(ℋ) > 1:
            λˣ_k = λ + (λˣ_k + α - λ) * (
                np.exp(-β * (t_k - t_prev)))
        else:
            λˣ_k = λ
    
    return ℋ[:-1]

def exp_simulate_by_composition_N(𝛉, N):
    λ, α, β = 𝛉
    λˣ_k = λ
    t_k = 0

    ℋ = np.empty(N, dtype=np.float64)
    for k in range(N):
        U_1 = rnd.rand()
        U_2 = rnd.rand()

        # Technically the following works, but without @njit
        # it will print out "RuntimeWarning: invalid value encountered in log".
        # This is because 1 + β/(λˣ_k + α - λ)*np.log(U_2) can be negative
        # so T_2 can be np.NaN. The Dassios & Zhao (2013) algorithm checks if this
        # expression is negative and handles it separately, though the lines
        # below have the same behaviour as t_k = min(T_1, np.NaN) will be T_1. 
        T_1 = t_k - np.log(U_1) / λ
        T_2 = t_k - np.log(1 + β/(λˣ_k + α - λ)*np.log(U_2))/β

        t_prev = t_k
        t_k = min(T_1, T_2)
        ℋ[k] = t_k

        if k > 0:
            λˣ_k = λ + (λˣ_k + α - λ) * (
                np.exp(-β * (t_k - t_prev)))
        else:
            λˣ_k = λ
          
    return ℋ

def exp_hawkes_intensity(t, ℋ_t, 𝛉):
    λ, α, β = 𝛉
    λˣ = λ
    ℋ_t = np.array(ℋ_t)
    ℋ_t = ℋ_t[ℋ_t < t]  # Filter events before time t
    for t_i in ℋ_t:
        λˣ += α * np.exp(-β * (t - t_i))
    return λˣ

def simulate_exact_composition_N(theta, Nmin, Nmax, num_realizations=100, key=123):

    numba_seed(key)
    # rnd.seed(key)
    event_list = []
    N_list = []
    for i in tqdm(range(num_realizations), desc="Simulating event lists"):
        N = rnd.randint(Nmin, Nmax)
        ℋ = exp_simulate_by_composition_N(theta, N)
        event_list.append(ℋ)
        N_list.append(N)
    return event_list, N_list


def simulate_exact_composition_T(theta, Tmin, Tmax, num_realizations=100, key=123):

    numba_seed(key)
    # rnd.seed(key)
    event_list = []
    T_list = []
    for i in tqdm(range(num_realizations), desc="Simulating event lists"):
        T = rnd.uniform(Tmin, Tmax)
        ℋ = exp_simulate_by_composition_T(theta, T)
        event_list.append(ℋ)
        T_list.append(T)
    return event_list, T_list


def simulate_self_correcting_T(T_max):
    t = 0
    events = []

    while t < T_max:
        u = np.random.uniform()
        k = len(events)

        t = np.log(-np.log(u)*np.exp(k) + np.exp(t))

        if t < T_max:
            events.append(t)
        else:
            break
        
    return np.array(events)


def simulate_self_correcting_N(n_points):
    """
    Simulate a self-correcting point process with intensity λ(t | H_t) = exp(t - N_t)
    until exactly `n_points` events are generated.
    """
    t = 0
    events = []

    while len(events) < n_points:
        N_t = len(events)
        u = np.random.uniform()
        t = np.log(-np.log(u)*np.exp(N_t) + np.exp(t))

        events.append(t)

    return np.array(events)

def self_correcting_compensators(ℋ_t):
    N_ts = np.arange(len(ℋ_t))
    Λ = 0
    Λs = np.empty(len(ℋ_t), dtype=np.float64)
    for i, N_t in enumerate(N_ts):
        Λ += np.exp(-N_t) * (np.exp(ℋ_t[i]) - np.exp(ℋ_t[i-1]) if i > 0 else np.exp(ℋ_t[i]))
        Λs[i] = Λ

    return Λs
    
def self_correcting_intensity(t,ℋ_t):
    ℋ_t = ℋ_t[ℋ_t < t]
    N_t = len(ℋ_t)

    return np.exp(t - N_t)

def simulate_lognormal_renewal_T(theta,T_max):
    """
    Simulate a stationary renewal process with log-normal inter-event intervals.
    Intervals are i.i.d. log-normal with given mean and std.
    Simulation stops when time exceeds T_max.
    """
    mean, std = theta
    events = []
    t = 0.0

    # Convert mean and std to log-normal parameters
    # mean = exp(mu + sigma^2/2), std^2 = (exp(sigma^2) - 1) * exp(2*mu + sigma^2)
    variance = std ** 2
    mu = np.log(mean ** 2 / np.sqrt(variance + mean ** 2))
    sigma = np.sqrt(np.log(variance / mean ** 2 + 1))

    while t < T_max:
        interval = np.random.lognormal(mean=mu, sigma=sigma)
        t += interval
        if t < T_max:
            events.append(t)
        else:
            break

    return np.array(events)

from scipy.stats import lognorm
def lognormal_renewal_compensators(theta,ℋ_t):
    mean, std = theta
    variance = std ** 2
    mu = np.log(mean ** 2 / np.sqrt(variance + mean ** 2))
    sigma = np.sqrt(np.log(variance / mean ** 2 + 1))
    
    t_diff = np.diff(ℋ_t, prepend=0)

    Λs = -np.log(1-lognorm.cdf(t_diff, s=sigma, scale=np.exp(mu)))
    return np.cumsum(Λs)

def lognormal_renewal_intensity(t, ℋ_t, theta):
    mean, std = theta
    variance = std ** 2
    mu = np.log(mean ** 2 / np.sqrt(variance + mean ** 2))
    sigma = np.sqrt(np.log(variance / mean ** 2 + 1))

    ℋ_t = ℋ_t[ℋ_t < t]
    if len(ℋ_t) == 0:
        last_event = 0
    else:
        last_event = ℋ_t[-1]

    t_diff = t - last_event

    return lognorm.pdf(t_diff, s=sigma, scale=np.exp(mu)) / lognorm.sf(t_diff, s=sigma, scale=np.exp(mu))

def simulate_lognormal_renewal_N(theta, n_events):
    """
    Simulate a stationary renewal process with log-normal inter-event intervals.
    Intervals are i.i.d. log-normal with given mean and std.
    Simulation stops after n_events events.
    """
    mean, std = theta
    variance = std ** 2
    mu = np.log(mean ** 2 / np.sqrt(variance + mean ** 2))
    sigma = np.sqrt(np.log(variance / mean ** 2 + 1))

    events = []
    t = 0.0

    # Convert mean and std to log-normal parameters
    for _ in range(n_events):
        interval = np.random.lognormal(mean=mu, sigma=sigma)
        t += interval
        events.append(t)

    return np.array(events)



class SyntheticFactory:
    def __init__(self, process_type, Tmin=0, Tmax=10):
        self.process_type = process_type.lower()
        self.Tmin = Tmin
        self.Tmax = Tmax

    def generate_T(self,num_realizations,key):
        numba_seed(key)
        results = []
        T_list = []
        for _ in range(num_realizations):
            T = np.random.uniform(self.Tmin, self.Tmax)
            T_list.append(T)
            if self.process_type == "lognormal":
                theta = [1.0,2.0]
                events = simulate_lognormal_renewal_T(theta, T)
            elif self.process_type == "self_correcting":
                events = simulate_self_correcting_T(T)
            elif self.process_type == "hawkes1":
                events = exp_simulate_by_composition_T([0.2,0.8,1.0], T)
            elif self.process_type == "hawkes2":
                events = exp_simulate_by_composition_T([0.3,0.5,2.5], T)
            else:
                raise ValueError(f"Unknown process type: {self.process_type}")
            results.append(events)
        return results, T_list
    

    def generate_n(self,num_realizations,N,key):
        numba_seed(key)
        results = []
        for _ in range(num_realizations):

            if self.process_type == "lognormal":
                theta = [1.0, 2.0]
                events = simulate_lognormal_renewal_N(theta, N)
            elif self.process_type == "self_correcting":
                events = simulate_self_correcting_N(N)
            elif self.process_type == "hawkes1":
                events = exp_simulate_by_composition_N([0.2,0.8,1.0], N)
            elif self.process_type == "hawkes2":
                events = exp_simulate_by_composition_N([0.3,0.5,2.5], N)
            else:
                raise ValueError(f"Unknown process type: {self.process_type}")
            results.append(events)
        return results

    def compute_compensators(self, events):
        if self.process_type == "self_correcting":
            return self_correcting_compensators(events)
        elif self.process_type == "hawkes1":
            θ = [0.2, 0.8, 1.0]
            return exp_hawkes_compensators(events, θ)
        elif self.process_type == "hawkes2":
            θ = [0.3, 0.5, 2.5]
            return exp_hawkes_compensators(events, θ)
        elif self.process_type == "lognormal":
            theta = [1.0, 2.0]
            return lognormal_renewal_compensators(theta, events)
        else:
            raise ValueError(f"Compensator not implemented for process type: {self.process_type}")
        
    def intensity(self, t, events):
        if self.process_type == "self_correcting":
            return self_correcting_intensity(t, events)
        elif self.process_type == "hawkes1":
            θ = [0.2, 0.8, 1.0]
            return exp_hawkes_intensity(t, events, θ)
        elif self.process_type == "hawkes2":
            θ = [0.3, 0.5, 2.5]
            return exp_hawkes_intensity(t, events, θ)
        elif self.process_type == "lognormal":
            # For renewal process, intensity is undefined in the same way; return None
            θ = [1.0, 2.0]
            return lognormal_renewal_intensity(t, events, θ)
        else:
            raise ValueError(f"Intensity not implemented for process type: {self.process_type}")
